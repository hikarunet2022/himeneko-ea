"""Execute extracted EA numeric/gate functions in a C++ fixture, NOT MetaEditor.
No ticks, broker execution, indicators or MT5 runtime are emulated/validated.
"""
from pathlib import Path
import re,subprocess,tempfile
source=Path(__file__).parents[1]/'HimenekoGoldV1.mq5'
s=source.read_text()
def function(name):
 m=re.search(r'(?m)^(?:bool|double|int) '+name+r'\(',s);start=m.start();i=s.index('{',m.end());depth=1;i+=1
 while depth:
  depth+=(s[i]=='{')-(s[i]=='}');i+=1
 return s[start:i]
fixture=r'''
#include <algorithm>
#include <cmath>
#include <cassert>
#include <iostream>
#include <string>
#include <vector>
using string=std::string;
template<class T> double MathMax(T a,T b){return std::max(a,b);}
template<class T> double MathMin(T a,T b){return std::min(a,b);}
double MathAbs(double x){return std::abs(x);} double MathFloor(double x){return std::floor(x);} double MathCeil(double x){return std::ceil(x);}
double NormalizeDouble(double x,int n){double scale=std::pow(10.,n);return std::round(x*scale)/scale;}
template<class T>int ArraySize(const std::vector<T>&v){return (int)v.size();}
enum ENUM_HN_RISK{RISK_PERCENT=0,VIDEO_BALANCE_STEP=1,FIXED_LOT=2};
enum ENUM_HN_TOUCH{MA_REBOUND=0,BODY_NEAR_MA=1,CLOSE_NEAR_MA=2};
enum ENUM_HN_ALIGN{STRICT_ALIGNMENT=0,NO_OPPOSING_TREND=1};
enum ENUM_HN_SL_BASIS{SWING_STOP=0,SIGNAL_CANDLE_STOP=1,ATR_STOP=2,FIXED_DISTANCE_STOP=3};
enum ENUM_ORDER_TYPE{ORDER_TYPE_BUY,ORDER_TYPE_SELL};
enum{SYMBOL_VOLUME_STEP,SYMBOL_VOLUME_MIN,SYMBOL_VOLUME_MAX,SYMBOL_TRADE_TICK_SIZE,SYMBOL_DIGITS,ACCOUNT_BALANCE,ACCOUNT_EQUITY};
string _Symbol="fixture",g_hnStatusText;
double _Point=.01,accountBalance=20,accountEquity=20,stepConversion=150;
double InpFixedLot=.1,InpMaxLot=10,InpRoundTripCostPerLot=0,InpRiskPercent=1,InpTouchATR=.2;
double InpWickBodyRatio=1.5,InpLowerWickPercent=40,InpUpperWickPercent=40,InpBodyFloorPoints=1,InpRSIBuyLevel=20,InpRSISellLevel=80;
bool InpUseWickFilter=true,InpUseRSI=true,InpRequireSignalColor=false,InpProportionalAboveLastStep=true,InpStopBelowFirstStep=false;
int InpRSILookback=1,InpSwingLookback=10;
ENUM_HN_RISK InpRiskMode=VIDEO_BALANCE_STEP;
ENUM_HN_TOUCH InpTouchMode=MA_REBOUND;
ENUM_HN_ALIGN InpTrendAlignment=STRICT_ALIGNMENT;
ENUM_HN_SL_BASIS InpSLBasis=SWING_STOP;
struct Candle{double open=100,close=101,low=95,high=102;};Candle bars[250];
double m3Fast[250],m3ATR[250],m3RSI[250];
struct Snapshot{double body=0,wick=0,wickRatio=0,wickPercent=0,rsiGate=20,riskMoney=0;};Snapshot snap;
std::vector<double>stepBalances={0,10000,30000,50000,100000,150000,300000,500000,1000000};
std::vector<double>stepLots={.1,.1,.2,.3,.5,.5,.7,1,1.6};
double SymbolInfoDouble(string,int key){switch(key){case SYMBOL_VOLUME_STEP:case SYMBOL_VOLUME_MIN:case SYMBOL_TRADE_TICK_SIZE:return .01;case SYMBOL_VOLUME_MAX:return 200;}return 0;}
long SymbolInfoInteger(string,int){return 2;}
double AccountInfoDouble(int key){return key==ACCOUNT_BALANCE?accountBalance:accountEquity;}
bool OrderCalcProfit(ENUM_ORDER_TYPE type,string,double lot,double entry,double stop,double&profit){profit=(type==ORDER_TYPE_BUY?stop-entry:entry-stop)*100*lot;return true;}
'''
fixture+='\n'.join(function(n) for n in ['AlignmentPass','Pullback','WickPass','EntrySignal','NormalizePrice','NormalizeLotDown','CalculateLot'])
fixture+=r'''
int main(){
 int checks=0;
 auto check=[&](bool b){assert(b);checks++;};auto near=[](double a,double b){return std::abs(a-b)<1e-8;};
 for(int i=0;i<250;i++){m3Fast[i]=100;m3ATR[i]=2;m3RSI[i]=30;bars[i]={100,101,95,102};}
 check(Pullback(1));check(WickPass(1));check(near(snap.wickRatio,5));
 double swing=0;snap.rsiGate=20;check(EntrySignal(1,swing));check(near(swing,95));
 snap.rsiGate=20.0001;check(!EntrySignal(1,swing));check(g_hnStatusText=="WAIT RSI");
 bars[1]={101,100,99,106};snap.rsiGate=80;check(EntrySignal(-1,swing));check(near(swing,106));
 snap.rsiGate=79.999;check(!EntrySignal(-1,swing));
 bars[1]={100,100,95,100};check(WickPass(1));check(std::isfinite(snap.wickRatio));
 bars[1]={100,100,100,100};check(!WickPass(1));
 bars[1]={100,101,100.5,102};check(!Pullback(1));
 InpTrendAlignment=STRICT_ALIGNMENT;check(!AlignmentPass(1,0));check(AlignmentPass(1,1));check(!AlignmentPass(1,-1));
 InpTrendAlignment=NO_OPPOSING_TREND;check(AlignmentPass(1,0));check(!AlignmentPass(1,-1));
 check(near(CalculateLot(1,100,95),.1));accountBalance=19;check(near(CalculateLot(1,100,95),.1));
 accountBalance=200;check(near(CalculateLot(1,100,95),.2));accountBalance=1000;check(near(CalculateLot(1,100,95),.5));
 accountBalance=1000000./150;check(near(CalculateLot(1,100,95),1.6));accountBalance=2000000./150;check(near(CalculateLot(1,100,95),3.2));
 stepConversion=1;accountBalance=3000;check(near(CalculateLot(1,100,95),.1));
 stepBalances[0]=3000;accountBalance=2999;InpStopBelowFirstStep=true;check(CalculateLot(1,100,95)==0);
 InpStopBelowFirstStep=false;check(near(CalculateLot(1,100,95),.1));
 InpRiskMode=RISK_PERCENT;accountBalance=1000;accountEquity=1000;check(near(CalculateLot(1,100,90),.01));
 check(CalculateLot(1,100,70)==0);check(NormalizeLotDown(.009)==0);check(near(NormalizeLotDown(.029),.02));
 check(near(NormalizePrice(100.005,-1),100));check(near(NormalizePrice(100.005,1),100.01));
 // Current/incomplete bar must never affect confirmed signal candle gates.
 InpRiskMode=VIDEO_BALANCE_STEP;bars[1]={100,101,95,102};snap.rsiGate=20;bool before=EntrySignal(1,swing);
 bars[0]={9999,1,0,10000};m3RSI[0]=100;snap.rsiGate=20;check(EntrySignal(1,swing)==before);
 // Explicit wider RSI window differs from default same-bar test.
 InpRSILookback=2;m3RSI[2]=19;snap.rsiGate=35;check(EntrySignal(1,swing));
 std::cout<<checks<<" extracted-core boundary assertions passed\n";
}
'''
with tempfile.TemporaryDirectory() as d:
 p=Path(d)/'core.cpp';p.write_text(fixture);binary=Path(d)/'core'
 subprocess.run(['g++','-std=c++17','-Wall','-Wextra','-Werror',str(p),'-o',str(binary)],check=True)
 subprocess.run([str(binary)],check=True)
