#!/usr/bin/env python3
"""Aggregate actual HN V1 MT5 CSVs. Monte Carlo is a closed-balance proxy only."""
import argparse
import csv
import json
import math
import random
from pathlib import Path


def read_csv(path):
    with open(path, encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def closed_trades(rows):
    groups, seen = {}, set()
    for row in rows:
        deal = row["deal_id"]
        if deal in seen:
            raise ValueError(f"Duplicate deal_id {deal}: do not mix repeated runs.")
        seen.add(deal)
        p = groups.setdefault(row["position_id"], {
            "position_id": row["position_id"], "in_volume": 0., "out_volume": 0.,
            "net": 0., "opened": "", "closed": "", "stop_out": False,
        })
        p["net"] += sum(float(row[k]) for k in ("profit", "commission", "swap", "fee"))
        entry = row["entry"]
        if entry == "DEAL_ENTRY_IN":
            p["in_volume"] += float(row["volume"])
            p["opened"] = min(p["opened"] or row["time"], row["time"])
        elif entry in ("DEAL_ENTRY_OUT", "DEAL_ENTRY_OUT_BY"):
            p["out_volume"] += float(row["volume"])
            p["closed"] = max(p["closed"], row["time"])
        else:
            raise ValueError(f"Unsupported entry kind {entry}; V1 does not reverse positions.")
        p["stop_out"] |= row["exit_reason"] == "STOP_OUT"
    completed, incomplete = [], []
    for p in groups.values():
        if p["in_volume"] > 0 and abs(p["in_volume"] - p["out_volume"]) < 1e-7:
            completed.append(p)
        else:
            incomplete.append(p["position_id"])
    return sorted(completed, key=lambda p: (p["closed"], p["position_id"])), incomplete


def closed_balance_metrics(trades, initial):
    if initial <= 0:
        raise ValueError("Initial balance must be positive.")
    balance = peak = initial
    dd_money = dd_pct = 0.
    streak = max_streak = 0
    wins, losses, returns = [], [], []
    for t in trades:
        pnl = t["net"]
        if balance <= 0:
            raise ValueError("Non-positive observed balance; bootstrap returns are undefined.")
        returns.append(pnl / balance)
        balance += pnl
        peak = max(peak, balance)
        dd_money = max(dd_money, peak - balance)
        dd_pct = max(dd_pct, (peak - balance) / peak * 100)
        if pnl < 0:
            losses.append(pnl)
            streak += 1
            max_streak = max(max_streak, streak)
        else:
            streak = 0
            if pnl > 0:
                wins.append(pnl)
    gross_win, gross_loss = sum(wins), abs(sum(losses))
    return {
        "completed_trades": len(trades), "final_closed_balance": balance,
        "net_profit_including_logged_costs": balance - initial,
        "closed_balance_dd_pct": dd_pct,
        "closed_trade_profit_factor": gross_win / gross_loss if gross_loss else None,
        "closed_trade_win_rate_pct": 100 * len(wins) / len(trades) if trades else 0.,
        "closed_trade_average_win": gross_win / len(wins) if wins else 0.,
        "closed_trade_average_loss": -gross_loss / len(losses) if losses else 0.,
        "closed_trade_max_consecutive_losses": max_streak,
        "closed_balance_recovery_factor": (balance - initial) / dd_money if dd_money else None,
        "actual_stop_out_events": sum(t["stop_out"] for t in trades),
    }, returns


def quantile(values, probability):
    v = sorted(values)
    index = (len(v) - 1) * probability
    lo, hi = math.floor(index), math.ceil(index)
    return v[lo] + (v[hi] - v[lo]) * (index - lo)


def monte_carlo_proxy(returns, initial, paths=10000, seed=261004, ruin_fraction=0.1, block=5):
    if len(returns) < 2:
        raise ValueError("At least two completed trades are needed.")
    if not 0 < ruin_fraction < 1 or paths < 1 or block < 1:
        raise ValueError("Invalid Monte Carlo inputs.")
    rng = random.Random(seed)
    ending, drawdowns, depleted = [], [], 0
    horizon = len(returns)
    for _ in range(paths):
        balance = peak = initial
        dd = 0.
        hit = False
        generated = 0
        while generated < horizon:
            start = rng.randrange(horizon)
            for j in range(min(block, horizon - generated)):
                ret = returns[(start + j) % horizon]
                balance = max(0., balance * (1 + ret))
                peak = max(peak, balance)
                dd = max(dd, (peak - balance) / peak * 100)
                generated += 1
                if balance <= initial * ruin_fraction:
                    hit = True
                if balance == 0:
                    break
            if balance == 0:
                break
        ending.append(balance)
        drawdowns.append(dd)
        depleted += hit
    return {
        "method": "circular block bootstrap of observed net closed-balance returns",
        "paths": paths, "seed": seed, "block_length_trades": block,
        "horizon_trades": horizon, "depletion_threshold_initial_fraction": ruin_fraction,
        "balance_depletion_proxy_pct": depleted / paths * 100,
        "final_balance_p05": quantile(ending, .05),
        "final_balance_p50": quantile(ending, .5),
        "final_balance_p95": quantile(ending, .95),
        "closed_balance_dd_pct_p95": quantile(drawdowns, .95),
        "limitations": "NOT a broker bankruptcy/stop-out probability. No intratrade equity, margin, lot steps, minimum lots, time filters or daily halt replay. Observed returns are regime-dependent; an unobserved crash cannot be inferred.",
    }


def compare(directory, output):
    rows = []
    for path in sorted(Path(directory).rglob("HN_V1*_summary.csv")):
        found = read_csv(path)
        if len(found) != 1:
            raise ValueError(f"Expected exactly one summary row: {path}")
        row = found[0]
        row["source"] = str(path)
        rows.append(row)
    if not rows:
        raise ValueError("No actual summary files found. Run MT5 first.")
    if any(set(r)!=set(rows[0]) for r in rows):
        raise ValueError("Do not mix EA versions with different summary schemas in one comparison.")
    tags = [r["run_tag"] for r in rows]
    if len(tags) != len(set(tags)):
        raise ValueError("Duplicate run_tag: place separate test periods in separate directories.")
    with open(output, "w", encoding="utf-8-sig", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    return {"summaries": len(rows), "output": str(output), "note": "MT5 equity drawdown and metrics are retained unchanged. Verify identical test settings."}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    sub = p.add_subparsers(dest="command", required=True)
    c = sub.add_parser("compare")
    c.add_argument("directory", type=Path)
    c.add_argument("--out", type=Path, required=True)
    a = sub.add_parser("analyze")
    a.add_argument("deals", type=Path)
    a.add_argument("--initial", type=float, required=True)
    a.add_argument("--out", type=Path, required=True)
    a.add_argument("--mc-paths", type=int, default=10000)
    a.add_argument("--seed", type=int, default=261004)
    a.add_argument("--block", type=int, default=5)
    a.add_argument("--ruin-fraction", type=float, default=.1)
    args = p.parse_args()
    if args.command == "compare":
        result = compare(args.directory, args.out)
    else:
        trades, incomplete = closed_trades(read_csv(args.deals))
        if incomplete:
            raise ValueError(f"Incomplete positions {incomplete}; use a full single-test log.")
        metrics, returns = closed_balance_metrics(trades, args.initial)
        result = {"source": str(args.deals), "initial_balance": args.initial,
                  "actual_closed_trade_metrics": metrics,
                  "monte_carlo_approximation": (
                      monte_carlo_proxy(returns, args.initial, args.mc_paths, args.seed, args.ruin_fraction, args.block)
                      if len(returns)>=2 else {"status": "not_computed", "reason": "fewer than two completed trades"})}
        args.out.write_text(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()
