"""Independent numeric boundary checks. These do NOT execute/compile the EA."""
import importlib.util
import math
import unittest
from pathlib import Path

spec = importlib.util.spec_from_file_location("analysis", Path(__file__).with_name("analyze_results.py"))
analysis = importlib.util.module_from_spec(spec)
spec.loader.exec_module(analysis)


def floor_lot(requested, minimum=.01, step=.01, maximum=10.):
    v = round(math.floor(min(requested, maximum) / step + 1e-9) * step, 8)
    return v if v >= minimum - 1e-9 else 0.


class NumericTests(unittest.TestCase):
    def test_minimum_lot_must_not_increase_risk(self):
        self.assertEqual(floor_lot(.009), 0.)
        self.assertEqual(floor_lot(.029), .02)
        self.assertEqual(floor_lot(100), 10.)

    def test_gold_risk_fixture(self):
        # Synthetic broker fixture: 100 oz/lot, $10 hard-stop distance.
        budget = 1000 * .01
        self.assertEqual(floor_lot(budget / (100 * 10)), .01)
        self.assertEqual(floor_lot(budget / (100 * 30)), 0.)

    def test_closed_stop_risk_and_tp_are_different_distances(self):
        entry, swing, atr = 3000., 2995., 2.
        logical = swing - atr * .1
        distance = entry - logical
        hard = entry - distance * 3
        tp = entry + distance * 1.5
        self.assertAlmostEqual(logical, 2994.8)
        self.assertAlmostEqual(hard, 2984.4)
        self.assertAlmostEqual(tp, 3007.8)
        self.assertAlmostEqual((tp-entry)/(entry-hard), .5)

    def test_snapshot_trade_net_includes_both_entry_and_exit_fees(self):
        def row(deal, entry, volume, profit=0., commission=0.):
            return dict(deal_id=deal, position_id="1", entry=entry, volume=str(volume),
                        profit=str(profit), commission=str(commission), swap="0", fee="0",
                        time="2026.10.01 00:00:00", exit_reason="RR_TP")
        rows = [row("1", "DEAL_ENTRY_IN", .1, commission=-1),
                row("2", "DEAL_ENTRY_OUT", .04, 5, -1),
                row("3", "DEAL_ENTRY_OUT", .06, 7, -1)]
        complete, incomplete = analysis.closed_trades(rows)
        self.assertFalse(incomplete)
        self.assertEqual(len(complete), 1)
        self.assertEqual(complete[0]["net"], 9)
        with self.assertRaises(ValueError):
            analysis.closed_trades(rows + rows[:1])

    def test_metrics_drawdown_streak_and_profit_factor(self):
        trades = [{"net": v, "stop_out": False} for v in (100., -50., -100., 200.)]
        m, returns = analysis.closed_balance_metrics(trades, 1000.)
        self.assertEqual(m["final_closed_balance"], 1150.)
        self.assertEqual(m["closed_trade_profit_factor"], 2.)
        self.assertEqual(m["closed_trade_max_consecutive_losses"], 2)
        self.assertAlmostEqual(m["closed_balance_dd_pct"], 150/1100*100)
        self.assertAlmostEqual(returns[1], -50/1100)

    def test_monte_carlo_boundary_and_reproducibility(self):
        positive = analysis.monte_carlo_proxy([.01, .02], 1000., paths=100, block=1)
        self.assertEqual(positive["balance_depletion_proxy_pct"], 0.)
        self.assertEqual(positive["closed_balance_dd_pct_p95"], 0.)
        depleted = analysis.monte_carlo_proxy([-1., -.99], 1000., paths=100, block=1)
        self.assertEqual(depleted["balance_depletion_proxy_pct"], 100.)
        self.assertEqual(depleted, analysis.monte_carlo_proxy([-1., -.99], 1000., paths=100, block=1))

    def test_incomplete_exit_rejected(self):
        row = dict(deal_id="1", position_id="1", entry="DEAL_ENTRY_IN", volume=".1",
                   profit="0", commission="-1", swap="0", fee="0", time="x", exit_reason="ENTRY")
        complete, incomplete = analysis.closed_trades([row])
        self.assertFalse(complete)
        self.assertEqual(incomplete, ["1"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
