# 入力パラメータ一覧

EAの初期値です。video.setだけはRiskMode=1、日次損失=20％、RunTag=videoになります。risk2/3/5はリスク％とRunTagを変更します。

|入力名|初期値|意味|
|---|---|---|
|`InpMagic`|`26100401`|EAの識別番号。ライブでは同一口座内で他のEA・別チャートと共用しない。|
|`InpAllowLiveTrading`|`false`|falseはライブ／デモの新規注文を禁止。テスターには影響しない。保有管理は継続。|
|`InpMaxPositions`|`1`|V1は1だけ有効。2以上は初期化を拒否し、ナンピンは行わない。|
|`InpMaxSpreadPoints`|`50`|新規注文のスプレッド上限。Point単位。0で無効。|
|`InpMaxSlippagePoints`|`20`|注文・決済時に渡す許容ずれ。Point単位。約定方式により厳密な上限にはならない。|
|`InpMarginUsePercent`|`80.0`|必要証拠金が余剰証拠金のこの割合を超える場合は見送り。lotを黙って縮小しない。|
|`InpRunTag`|`risk1`|結果ファイル識別用。半角英数字・_・-の1〜32文字。|
|`InpWriteCSV`|`true`|単独実行で約定CSVとテスター統計CSVを出力。最適化中は出力しない。|
|`InpRiskMode`|`0`|0=RiskPercent、1=動画風の残高別lot、2=固定lot。|
|`InpRiskPercent`|`1.0`|リスク予算の割合。RiskPercentモードだけで使用。終値SLでは緊急逆指値までを基準とする。|
|`InpFixedLot`|`0.01`|固定lotモードだけで使用。|
|`InpMaxLot`|`10.0`|全ロット方式の上限。ブローカー上限も併用。|
|`InpRoundTripCostPerLot`|`0.0`|損失見積もりに加える往復費用／1lot。口座通貨。0では費用をサイズ計算に加えない。|
|`InpStepCurrency`|`JPY`|残高段階表の通貨。動画風モードの口座通貨との完全一致を要求。自動換算ではない。|
|`InpBalanceLotSteps`|`READMEの円建て段階表`|残高閾値:lotをセミコロン区切りで指定。閾値は正の昇順。最初の閾値未満では取引しない。|
|`InpProportionalAboveLastStep`|`true`|最後の残高閾値を超えたらlotを比例増額。falseなら最後のlotに据え置き。|
|`InpFastMA`|`20`|M15方向とM3押し目・トリガーに使うMA期間。|
|`InpSlowMA`|`50`|追加の並び順フィルター用MA期間。フィルターfalseの初期設定では売買判断に使わない。|
|`InpTrendMA`|`200`|D1/H4/H1方向判定に使うMA期間。|
|`InpMAMethod`|`1`|MA種類。0=SMA、1=EMA、2=SMMA、3=LWMA。全時間足で共通。|
|`InpMAPrice`|`1`|MA計算に使う価格。1=終値、2=始値、3=高値、4=安値、5=中央、6=平均、7=加重終値。|
|`InpSlopeBars`|`3`|MA[1]とMA[1+N]を比較する本数。傾きはATRで割って評価。|
|`InpMinTrendSlopeATR`|`0.02`|D1/H4/H1/M15で方向を認める最小傾き。ATRに対する比率。|
|`InpFlatSlopeATR`|`0.02`|M3の水平と上向き／下向きを分ける境界。絶対傾きが以下なら水平。|
|`InpUseSlowMAFilter`|`false`|trueでM15/M3のFastMAとSlowMAの並びを確認。初期値falseは動画にない追加制約を外す。|
|`InpUseADX`|`true`|H1 ADXによるレンジ回避を有効にする。|
|`InpADXPeriod`|`14`|H1 ADX期間。|
|`InpMinADX`|`20.0`|H1 ADXがこの値以上で新規取引を許可。ADXフィルターON時。|
|`InpATRPeriod`|`14`|ATR期間。各時間足の傾き正規化、M3押し目・SLで使用。|
|`InpMinATR`|`0.0`|M3 ATR下限。価格単位。0で下限を無効化。|
|`InpMaxATR`|`0.0`|M3 ATR上限。価格単位。0で上限を無効化。|
|`InpPullbackLookback`|`12`|シグナル足を除いた過去何本で接近・反対色・反対傾きを探すか。|
|`InpTouchATR`|`0.2`|MA接近許容距離。該当足のATR×この値。|
|`InpTouchMode`|`0`|0=高値〜安値の区間とMAの距離、1=終値とMAの距離。|
|`InpEntryTrigger`|`3`|0=傾き転換、1=陽線／陰線、2=直前足高安の終値突破、3=転換＋陽線／陰線。|
|`InpRequireFlatPhase`|`true`|傾き転換に直前足の水平を要求。傾きトリガーを使わないモードには影響しない。|
|`InpRequireOppositeCandle`|`true`|押し目期間にロングなら陰線、ショートなら陽線を要求。|
|`InpRequireSwingUnbroken`|`true`|シグナル足の安値／高値が既存Swingを割る／超える場合は見送る。|
|`InpSwingLookback`|`10`|シグナル足を除いた過去何本の最安値／最高値をSwingとするか。|
|`InpSLBufferATR`|`0.1`|Swingの外側へ加える損切り余裕。シグナル足ATR×この値。|
|`InpSLMode`|`1`|0=固定逆指値、1=M3終値判定＋緊急逆指値。|
|`InpEmergencySLMultiplier`|`3.0`|終値SLだけで使用。注文価格〜論理SL幅に対する緊急SL距離の倍率。1以上。|
|`InpRiskReward`|`1.5`|注文価格〜論理SL幅に対するTP幅の倍率。緊急SL幅への倍率ではない。|
|`InpMaxDailyLossPercent`|`3.0`|日初残高に対する日次損失上限。自己の当日実現損益＋現在の含み損益で判定。0で無効。|
|`InpCloseOnDailyLoss`|`true`|日次停止時に自己ポジションを決済。falseでも当日の新規取引は停止。|
|`InpMaxDailyTrades`|`5`|サーバー日ごとの新規約定注文数上限。0で無効。部分約定は同じ注文を1件とする。|
|`InpMaxConsecutiveLosses`|`3`|当日全決済された取引の費用込み連敗上限。到達で当日停止。0で無効。|

主な追加補完は、傾き閾値0.02 ATR、水平0.02 ATR、押し目探索12本、緊急SL倍率3、スプレッド50 points、許容ずれ20 points、最大lot10、日次5回・3連敗停止です。これらは動画で確定した数値ではありません。
