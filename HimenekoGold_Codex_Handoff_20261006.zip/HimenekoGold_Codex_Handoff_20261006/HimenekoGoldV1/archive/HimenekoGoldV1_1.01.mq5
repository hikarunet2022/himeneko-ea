#property strict
#property version "1.01"
#property description "Research V1: closed-bar MTF gold pullback. Not a verified reproduction."
#include <Trade/Trade.mqh>

enum ENUM_HN_RISK { RISK_PERCENT=0, VIDEO_BALANCE_STEP=1, FIXED_LOT=2 };
enum ENUM_HN_SL { FIXED_STOP=0, CLOSE_BAR_STOP=1 };
enum ENUM_HN_TRIGGER { SLOPE_TURN=0, CANDLE_CONFIRM=1, BREAKOUT_CONFIRM=2, SLOPE_AND_CANDLE=3 };
enum ENUM_HN_TOUCH { CANDLE_RANGE_TOUCH=0, CLOSE_PRICE_TOUCH=1 };

input group "Identity / execution"
input ulong InpMagic=26100401;
input bool InpAllowLiveTrading=false; // tester works; live/demo entries need explicit true
input int InpMaxPositions=1;          // V1 accepts 1 only, no averaging
input int InpMaxSpreadPoints=50;
input int InpMaxSlippagePoints=20;
input double InpMarginUsePercent=80.0;
input string InpRunTag="risk1";      // letters/digits/_/- only, unique per test
input bool InpWriteCSV=true;

input group "Risk / account currency"
input ENUM_HN_RISK InpRiskMode=RISK_PERCENT;
input double InpRiskPercent=1.0;
input double InpFixedLot=0.01;
input double InpMaxLot=10.0;
input double InpRoundTripCostPerLot=0.0; // account currency, conservative fee allowance
input string InpStepCurrency="JPY";
input string InpBalanceLotSteps="3000:0.1;10000:0.1;30000:0.2;50000:0.3;100000:0.4;150000:0.5;300000:0.7;500000:1.0;1000000:1.6;2000000:2.5";
input bool InpProportionalAboveLastStep=true;

input group "Trend / indicators (all calculations use closed bars)"
input int InpFastMA=20;
input int InpSlowMA=50;
input int InpTrendMA=200;
input ENUM_MA_METHOD InpMAMethod=MODE_EMA;
input ENUM_APPLIED_PRICE InpMAPrice=PRICE_CLOSE;
input int InpSlopeBars=3;
input double InpMinTrendSlopeATR=0.02; // (MA[1]-MA[1+N])/ATR[1], not per-bar slope
input double InpFlatSlopeATR=0.02;
input bool InpUseSlowMAFilter=false;  // optional M15/M3 fast/slow ordering
input bool InpUseADX=true;
input int InpADXPeriod=14;
input double InpMinADX=20.0;
input int InpATRPeriod=14;
input double InpMinATR=0.0;          // M3 price units, 0 disables bound
input double InpMaxATR=0.0;

input group "M3 pullback / trigger"
input int InpPullbackLookback=12;
input double InpTouchATR=0.2;
input ENUM_HN_TOUCH InpTouchMode=CANDLE_RANGE_TOUCH;
input ENUM_HN_TRIGGER InpEntryTrigger=SLOPE_AND_CANDLE;
input bool InpRequireFlatPhase=true;
input bool InpRequireOppositeCandle=true;
input bool InpRequireSwingUnbroken=true;
input int InpSwingLookback=10;
input double InpSLBufferATR=0.1;
input ENUM_HN_SL InpSLMode=CLOSE_BAR_STOP;
input double InpEmergencySLMultiplier=3.0; // risk sizing uses this hard stop in CLOSE_BAR_STOP
input double InpRiskReward=1.5;             // TP uses logical swing-stop distance

input group "Daily limits (server day; 0 disables numerical limit)"
input double InpMaxDailyLossPercent=3.0;
input bool InpCloseOnDailyLoss=true;
input int InpMaxDailyTrades=5;
input int InpMaxConsecutiveLosses=3;

struct Snapshot
  {
   int d1,h4,h1,m15;
   double slope,adx,atr,spread,logicalSL,tp,riskMoney;
  };
CTrade trade;
ENUM_TIMEFRAMES frames[5]={PERIOD_D1,PERIOD_H4,PERIOD_H1,PERIOD_M15,PERIOD_M3};
int trendMA[3],fastMA[2],slowMA[2],atrHandle[5],adxHandle=INVALID_HANDLE;
double stepBalances[],stepLots[];
MqlRates bars[];
double m3Fast[],m3ATR[];
Snapshot snap;
Snapshot panel;
ulong statePositionId=0;
datetime lastBar=0,dayStart=0,lastHistoryRefresh=0,lastCloseAttempt=0,panelBar=0;
double dayStartBalance=0,realizedToday=0,lastLot=0,currentSpread=0;
int tradesToday=0,lossStreak=0,logHandle=INVALID_HANDLE;
bool dayHalted=false,historyDirty=true,historyOK=false,tester=false;
string g_hnStatusText="INITIALIZING",statePrefix="",pendingCloseReason="";
bool stateHealthy=true;

string IdText(const ulong id) { return StringFormat("%I64u",id); }
datetime ServerDay(const datetime value)
  {
   MqlDateTime t; TimeToStruct(value,t); t.hour=0; t.min=0; t.sec=0;
   return StructToTime(t);
  }
string StateKey(const ulong id,const string suffix)
  { return statePrefix+IdText(id)+"."+suffix; }
bool ValidTag()
  {
   if(StringLen(InpRunTag)<1 || StringLen(InpRunTag)>32) return false;
   for(int i=0;i<StringLen(InpRunTag);i++)
     {
      ushort c=StringGetCharacter(InpRunTag,i);
      if(!((c>=48 && c<=57)||(c>=65 && c<=90)||(c>=97 && c<=122)||c==95||c==45)) return false;
     }
   return true;
  }
bool ParseSteps()
  {
   string rows[];
   int n=StringSplit(InpBalanceLotSteps,StringGetCharacter(";",0),rows);
   if(n<1) return false;
   ArrayResize(stepBalances,n); ArrayResize(stepLots,n);
   for(int i=0;i<n;i++)
     {
      string pair[];
      if(StringSplit(rows[i],StringGetCharacter(":",0),pair)!=2) return false;
      stepBalances[i]=StringToDouble(pair[0]); stepLots[i]=StringToDouble(pair[1]);
      if(stepBalances[i]<=0 || stepLots[i]<=0 || (i>0 && stepBalances[i]<=stepBalances[i-1])) return false;
     }
   return true;
  }
bool BufferValue(const int handle,const int buffer,const int shift,double &value)
  {
   double v[1];
   if(handle==INVALID_HANDLE || BarsCalculated(handle)<=shift || CopyBuffer(handle,buffer,shift,1,v)!=1) return false;
   value=v[0]; return MathIsValidNumber(value) && value!=EMPTY_VALUE;
  }
int TrendDirection(const int ma,const int atr,const ENUM_TIMEFRAMES tf,const bool slowFilter,const int slow)
  {
   double now,before,av,sv;
   if(!BufferValue(ma,0,1,now)||!BufferValue(ma,0,1+InpSlopeBars,before)||!BufferValue(atr,0,1,av)||av<=0) return 0;
   double close=iClose(_Symbol,tf,1);
   if(close<=0) return 0;
   double normalized=(now-before)/av;
   int dir=0;
   if(close>now && normalized>InpMinTrendSlopeATR) dir=1;
   if(close<now && normalized<-InpMinTrendSlopeATR) dir=-1;
   if(slowFilter)
     {
      if(!BufferValue(slow,0,1,sv)) return 0;
      if((dir==1 && now<=sv)||(dir==-1 && now>=sv)) return 0;
     }
   return dir;
  }
bool ReadSignalData()
  {
   for(int i=0;i<5;i++)
     {
      int needed=(i<3 ? InpTrendMA : (int)MathMax(InpFastMA,InpSlowMA))+InpSlopeBars+2;
      if(Bars(_Symbol,frames[i])<needed || BarsCalculated(atrHandle[i])<needed) return false;
     }
   int need=(int)MathMax(InpPullbackLookback+InpSlopeBars+3,InpSwingLookback+3);
   ArraySetAsSeries(bars,true); ArraySetAsSeries(m3Fast,true); ArraySetAsSeries(m3ATR,true);
   if(CopyRates(_Symbol,PERIOD_M3,0,need,bars)!=need ||
      CopyBuffer(fastMA[1],0,0,need,m3Fast)!=need ||
      CopyBuffer(atrHandle[4],0,0,need,m3ATR)!=need) return false;
   for(int i=1;i<need;i++)
      if(m3ATR[i]<=0 || m3ATR[i]==EMPTY_VALUE || !MathIsValidNumber(m3ATR[i]) ||
         m3Fast[i]==EMPTY_VALUE || !MathIsValidNumber(m3Fast[i])) return false;
   if(!BufferValue(adxHandle,0,1,snap.adx)) return false;
   snap.atr=m3ATR[1]; snap.slope=(m3Fast[1]-m3Fast[1+InpSlopeBars])/snap.atr;
   snap.d1=TrendDirection(trendMA[0],atrHandle[0],PERIOD_D1,false,INVALID_HANDLE);
   snap.h4=TrendDirection(trendMA[1],atrHandle[1],PERIOD_H4,false,INVALID_HANDLE);
   snap.h1=TrendDirection(trendMA[2],atrHandle[2],PERIOD_H1,false,INVALID_HANDLE);
   snap.m15=TrendDirection(fastMA[0],atrHandle[3],PERIOD_M15,InpUseSlowMAFilter,slowMA[0]);
   return true;
  }
bool Pullback(const int dir)
  {
   bool touched=false,oppositeCandle=false;
   // Touch and counter-direction candle must precede the signal candle.
   for(int s=2;s<=InpPullbackLookback+1;s++)
     {
      double distance=0;
      if(InpTouchMode==CLOSE_PRICE_TOUCH) distance=MathAbs(bars[s].close-m3Fast[s]);
      else distance=MathMax(0.0,MathMax(bars[s].low-m3Fast[s],m3Fast[s]-bars[s].high));
      if(distance<=m3ATR[s]*InpTouchATR) touched=true;
      if(dir*(bars[s].close-bars[s].open)<0) oppositeCandle=true;
     }
   return touched && (!InpRequireOppositeCandle || oppositeCandle);
  }
bool SlopeTurn(const int dir)
  {
   if(dir*snap.slope<=InpFlatSlopeATR) return false;
   double prior=(m3Fast[2]-m3Fast[2+InpSlopeBars])/m3ATR[2];
   if(dir*prior>InpFlatSlopeATR) return false; // a fresh turn, not every bar in an existing upslope
   if(InpRequireFlatPhase && MathAbs(prior)>InpFlatSlopeATR) return false;
   bool flatSeen=!InpRequireFlatPhase;
   // Walk from the recent flat phase back to the preceding opposing slope.
   for(int s=2;s<=InpPullbackLookback+1;s++)
     {
      double slope=(m3Fast[s]-m3Fast[s+InpSlopeBars])/m3ATR[s];
      if(MathAbs(slope)<=InpFlatSlopeATR) flatSeen=true;
      if(flatSeen && dir*slope<-InpFlatSlopeATR) return true;
     }
   return false;
  }
bool EntrySignal(const int dir,double &swing)
  {
   if(!Pullback(dir)) { g_hnStatusText="WAIT PULLBACK"; return false; }
   bool candle=dir*(bars[1].close-bars[1].open)>0;
   bool turn=SlopeTurn(dir);
   bool breakout=(dir==1 ? bars[1].close>bars[2].high : bars[1].close<bars[2].low);
   bool trigger=false;
   switch(InpEntryTrigger)
     {
      case SLOPE_TURN: trigger=turn; break;
      case CANDLE_CONFIRM: trigger=candle; break;
      case BREAKOUT_CONFIRM: trigger=breakout; break;
      case SLOPE_AND_CANDLE: trigger=turn && candle; break;
     }
   if(!trigger || dir*(bars[1].close-m3Fast[1])<=0) { g_hnStatusText="WAIT TRIGGER"; return false; }
   if(InpUseSlowMAFilter)
     {
      double slow;
      if(!BufferValue(slowMA[1],0,1,slow)||dir*(m3Fast[1]-slow)<=0) { g_hnStatusText="M3 SLOW FILTER"; return false; }
     }
   // Rolling extreme of 10 prior CLOSED bars; no future-dependent pivot.
   swing=(dir==1 ? bars[2].low : bars[2].high);
   for(int s=3;s<=InpSwingLookback+1;s++) swing=(dir==1 ? MathMin(swing,bars[s].low) : MathMax(swing,bars[s].high));
   if(InpRequireSwingUnbroken && ((dir==1 && bars[1].low<swing)||(dir==-1 && bars[1].high>swing)))
     { g_hnStatusText="SWING BROKEN"; return false; }
   return true;
  }
bool OwnSelectedPosition()
  {
   return PositionGetString(POSITION_SYMBOL)==_Symbol && (ulong)PositionGetInteger(POSITION_MAGIC)==InpMagic;
  }
int OwnPositions()
  {
   int count=0;
   for(int i=0;i<PositionsTotal();i++) if(PositionGetTicket(i)!=0 && OwnSelectedPosition()) count++;
   return count;
  }
bool AnySymbolExposure()
  {
   for(int i=0;i<PositionsTotal();i++) if(PositionGetTicket(i)!=0 && PositionGetString(POSITION_SYMBOL)==_Symbol) return true;
   for(int i=0;i<OrdersTotal();i++) if(OrderGetTicket(i)!=0 && OrderGetString(ORDER_SYMBOL)==_Symbol) return true;
   return false;
  }
bool PositionIsOpen(const ulong id)
  {
   for(int i=0;i<PositionsTotal();i++)
      if(PositionGetTicket(i)!=0 && (ulong)PositionGetInteger(POSITION_IDENTIFIER)==id) return true;
   return false;
  }
double FloatingPL()
  {
   double sum=0;
   for(int i=0;i<PositionsTotal();i++)
      if(PositionGetTicket(i)!=0 && OwnSelectedPosition()) sum+=PositionGetDouble(POSITION_PROFIT)+PositionGetDouble(POSITION_SWAP);
   return sum;
  }
double DealNet(const ulong id)
  { return HistoryDealGetDouble(id,DEAL_PROFIT)+HistoryDealGetDouble(id,DEAL_COMMISSION)+HistoryDealGetDouble(id,DEAL_SWAP)+HistoryDealGetDouble(id,DEAL_FEE); }
bool HasId(const ulong &ids[],const ulong id)
  { for(int i=0;i<ArraySize(ids);i++) if(ids[i]==id) return true; return false; }
void AppendId(ulong &ids[],const ulong id)
  { int n=ArraySize(ids); ArrayResize(ids,n+1); ids[n]=id; }
bool StrategyDeal(const ulong id,const ulong &owned[])
  {
   if(HistoryDealGetString(id,DEAL_SYMBOL)!=_Symbol || ArraySize(owned)==0) return false;
   ulong pid=(ulong)HistoryDealGetInteger(id,DEAL_POSITION_ID);
   int index=ArrayBsearch(owned,pid);
   return index>=0 && owned[index]==pid;
  }
bool RefreshHistory()
  {
   datetime now=TimeCurrent(),newDay=ServerDay(now);
   bool changed=(newDay!=dayStart);
   if(changed)
     {
      dayStart=newDay; dayHalted=false;
      if(OwnPositions()==0) pendingCloseReason="";
      if(!tester && GlobalVariableCheck(statePrefix+"haltDay")) dayHalted=((datetime)GlobalVariableGet(statePrefix+"haltDay")==dayStart);
     }
   if(!HistorySelect(0,now)) { historyOK=false; return false; }
   int n=HistoryDealsTotal(); ulong owned[],entryOrders[];
   // Collect strategy position ids from entry magic, including manually closed exits.
   for(int i=0;i<n;i++)
     {
      ulong id=HistoryDealGetTicket(i);
      if(HistoryDealGetString(id,DEAL_SYMBOL)==_Symbol && (ulong)HistoryDealGetInteger(id,DEAL_MAGIC)==InpMagic &&
         (ENUM_DEAL_ENTRY)HistoryDealGetInteger(id,DEAL_ENTRY)==DEAL_ENTRY_IN)
        { ulong pid=(ulong)HistoryDealGetInteger(id,DEAL_POSITION_ID); AppendId(owned,pid); }
     }
   ArraySort(owned);
   realizedToday=0; tradesToday=0; lossStreak=0; double accountChange=0;
   ulong completed[];
   for(int i=0;i<n;i++)
     {
      ulong id=HistoryDealGetTicket(i); datetime t=(datetime)HistoryDealGetInteger(id,DEAL_TIME);
      if(t>=dayStart) accountChange+=DealNet(id);
      if(!StrategyDeal(id,owned)) continue;
      ENUM_DEAL_ENTRY entry=(ENUM_DEAL_ENTRY)HistoryDealGetInteger(id,DEAL_ENTRY);
      if(t>=dayStart)
        {
         realizedToday+=DealNet(id);
         if(entry==DEAL_ENTRY_IN)
           { ulong oid=(ulong)HistoryDealGetInteger(id,DEAL_ORDER); if(!HasId(entryOrders,oid)) { AppendId(entryOrders,oid); tradesToday++; } }
        }
     }
   // Today's completed positions only. Total lifecycle P/L includes entry fees.
   for(int i=n-1;i>=0;i--)
     {
      ulong id=HistoryDealGetTicket(i); datetime t=(datetime)HistoryDealGetInteger(id,DEAL_TIME);
      if(t<dayStart) break;
      if(!StrategyDeal(id,owned)) continue;
      ENUM_DEAL_ENTRY entry=(ENUM_DEAL_ENTRY)HistoryDealGetInteger(id,DEAL_ENTRY);
      if(entry!=DEAL_ENTRY_OUT && entry!=DEAL_ENTRY_OUT_BY) continue;
      ulong pid=(ulong)HistoryDealGetInteger(id,DEAL_POSITION_ID);
      if(HasId(completed,pid) || PositionIsOpen(pid)) continue;
      AppendId(completed,pid); double net=0;
      for(int j=0;j<n;j++)
        { ulong d=HistoryDealGetTicket(j); if(StrategyDeal(d,owned) && (ulong)HistoryDealGetInteger(d,DEAL_POSITION_ID)==pid) net+=DealNet(d); }
      if(net<0) lossStreak++; else break;
     }
   dayStartBalance=AccountInfoDouble(ACCOUNT_BALANCE)-accountChange;
   historyDirty=false; lastHistoryRefresh=now; historyOK=(dayStartBalance>0);
   return historyOK;
  }
void LatchDailyStop()
  {
   if(dayHalted) return;
   dayHalted=true;
   if(!tester) { GlobalVariableSet(statePrefix+"haltDay",(double)dayStart); GlobalVariablesFlush(); }
  }
void SavePositionState(const ulong id)
  {
   statePositionId=id;
   if(tester) return;
   // SL is the commit marker; store the rest first.
   GlobalVariableSet(StateKey(id,"D1"),snap.d1); GlobalVariableSet(StateKey(id,"H4"),snap.h4);
   GlobalVariableSet(StateKey(id,"H1"),snap.h1); GlobalVariableSet(StateKey(id,"M15"),snap.m15);
   GlobalVariableSet(StateKey(id,"slope"),snap.slope); GlobalVariableSet(StateKey(id,"adx"),snap.adx);
   GlobalVariableSet(StateKey(id,"atr"),snap.atr); GlobalVariableSet(StateKey(id,"spread"),snap.spread);
   GlobalVariableSet(StateKey(id,"tp"),snap.tp); GlobalVariableSet(StateKey(id,"risk"),snap.riskMoney);
   GlobalVariableSet(StateKey(id,"close"),0.0);
   stateHealthy=(GlobalVariableSet(StateKey(id,"SL"),snap.logicalSL)!=0);
   GlobalVariablesFlush();
  }
bool LoadPositionState(const ulong id)
  {
   if(id==statePositionId) return stateHealthy;
   if(tester || !GlobalVariableCheck(StateKey(id,"SL"))) return false;
   snap.logicalSL=GlobalVariableGet(StateKey(id,"SL")); snap.tp=GlobalVariableGet(StateKey(id,"tp"));
   snap.d1=(int)GlobalVariableGet(StateKey(id,"D1")); snap.h4=(int)GlobalVariableGet(StateKey(id,"H4"));
   snap.h1=(int)GlobalVariableGet(StateKey(id,"H1")); snap.m15=(int)GlobalVariableGet(StateKey(id,"M15"));
   snap.slope=GlobalVariableGet(StateKey(id,"slope")); snap.adx=GlobalVariableGet(StateKey(id,"adx"));
   snap.atr=GlobalVariableGet(StateKey(id,"atr")); snap.spread=GlobalVariableGet(StateKey(id,"spread"));
   snap.riskMoney=GlobalVariableGet(StateKey(id,"risk")); statePositionId=id;
   int pending=(int)GlobalVariableGet(StateKey(id,"close"));
   if(pending==1) pendingCloseReason="CLOSE_BAR_SL";
   if(pending==2) pendingCloseReason="DAILY_LOSS_LIMIT";
   if(pending==3) pendingCloseReason="MISSING_STOP_STATE";
   stateHealthy=(snap.logicalSL>0); return stateHealthy;
  }
bool TradeDone(const bool returned)
  {
   uint r=trade.ResultRetcode();
   return returned && (r==TRADE_RETCODE_DONE || r==TRADE_RETCODE_DONE_PARTIAL);
  }
void CloseOwned(const string reason)
  {
   if(TimeCurrent()==lastCloseAttempt) return;
   lastCloseAttempt=TimeCurrent();
   for(int i=PositionsTotal()-1;i>=0;i--)
     {
      ulong ticket=PositionGetTicket(i); if(ticket==0 || !OwnSelectedPosition()) continue;
      pendingCloseReason=reason;
      if(!tester)
        {
         ulong pid=(ulong)PositionGetInteger(POSITION_IDENTIFIER);
         int code=(reason=="CLOSE_BAR_SL" ? 1 : (reason=="DAILY_LOSS_LIMIT" ? 2 : 3));
         GlobalVariableSet(StateKey(pid,"close"),code); GlobalVariablesFlush();
        }
      if(!TradeDone(trade.PositionClose(ticket,(ulong)InpMaxSlippagePoints)))
         PrintFormat("CLOSE_FAILED %s: %u %s",reason,trade.ResultRetcode(),trade.ResultRetcodeDescription());
      historyDirty=true;
     }
  }
void ManageStops()
  {
   for(int i=PositionsTotal()-1;i>=0;i--)
     {
      ulong ticket=PositionGetTicket(i); if(ticket==0 || !OwnSelectedPosition()) continue;
      ulong pid=(ulong)PositionGetInteger(POSITION_IDENTIFIER);
      if(pendingCloseReason!="") { CloseOwned(pendingCloseReason); return; }
      bool stored=LoadPositionState(pid);
      if(pendingCloseReason!="") { CloseOwned(pendingCloseReason); return; }
      if(InpSLMode!=CLOSE_BAR_STOP) continue;
      if(!stored) { g_hnStatusText="MISSING STOP STATE"; CloseOwned("MISSING_STOP_STATE"); return; }
      double close=iClose(_Symbol,PERIOD_M3,1); if(close<=0) continue;
      ENUM_POSITION_TYPE type=(ENUM_POSITION_TYPE)PositionGetInteger(POSITION_TYPE);
      if((type==POSITION_TYPE_BUY && close<=snap.logicalSL)||(type==POSITION_TYPE_SELL && close>=snap.logicalSL))
        { CloseOwned("CLOSE_BAR_SL"); return; } // retries on following ticks if failed/partial
     }
  }
double NormalizePrice(const double price,const int rounding)
  {
   double size=SymbolInfoDouble(_Symbol,SYMBOL_TRADE_TICK_SIZE);
   if(size<=0) return 0;
   double units=price/size;
   double rounded=(rounding<0 ? MathFloor(units+1e-9) : MathCeil(units-1e-9));
   return NormalizeDouble(rounded*size,(int)SymbolInfoInteger(_Symbol,SYMBOL_DIGITS));
  }
double NormalizeLotDown(const double requested)
  {
   double step=SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_STEP),minimum=SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_MIN);
   double maximum=MathMin(InpMaxLot,SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_MAX));
   if(step<=0 || requested<=0 || maximum<minimum) return 0;
   double lot=NormalizeDouble(MathFloor(MathMin(requested,maximum)/step+1e-9)*step,8);
   if(lot<minimum-1e-9) return 0; // never round UP to the broker's minimum
   return lot;
  }
double CalculateLot(const int dir,const double entry,const double hardSL)
  {
   double requested=InpFixedLot;
   if(InpRiskMode==VIDEO_BALANCE_STEP)
     {
      double balance=AccountInfoDouble(ACCOUNT_BALANCE); int n=ArraySize(stepBalances);
      if(n<1 || balance<stepBalances[0]) { g_hnStatusText="BELOW FIRST LOT STEP"; return 0; }
      requested=stepLots[0];
      for(int i=1;i<n;i++) if(balance>=stepBalances[i]) requested=stepLots[i];
      if(InpProportionalAboveLastStep && balance>stepBalances[n-1]) requested=stepLots[n-1]*balance/stepBalances[n-1];
     }
   ENUM_ORDER_TYPE type=(dir==1 ? ORDER_TYPE_BUY : ORDER_TYPE_SELL);
   double reference=SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_MIN),profit=0;
   if(reference<=0 || !OrderCalcProfit(type,_Symbol,reference,entry,hardSL,profit) || profit>=0)
     { g_hnStatusText="RISK CALC FAILED"; return 0; }
   double unitLoss=MathAbs(profit)/reference+InpRoundTripCostPerLot;
   if(InpRiskMode==RISK_PERCENT)
     {
      double base=MathMin(AccountInfoDouble(ACCOUNT_BALANCE),AccountInfoDouble(ACCOUNT_EQUITY));
      requested=(base*InpRiskPercent/100.0)/unitLoss;
     }
   double lot=NormalizeLotDown(requested);
   if(lot<=0) { g_hnStatusText="LOT BELOW MINIMUM"; return 0; }
   snap.riskMoney=unitLoss*lot; return lot;
  }
bool StopsValid(const int dir,const MqlTick &tick,const double sl,const double tp)
  {
   double minDistance=SymbolInfoInteger(_Symbol,SYMBOL_TRADE_STOPS_LEVEL)*_Point;
   double market=(dir==1 ? tick.bid : tick.ask);
   return sl>0 && tp>0 && dir*(market-sl)>minDistance && dir*(tp-market)>minDistance;
  }
void TryEntry(const int dir,const double swing,const MqlTick &tick)
  {
   double entry=(dir==1 ? tick.ask : tick.bid);
   snap.logicalSL=NormalizePrice(swing-dir*snap.atr*InpSLBufferATR,-dir);
   double distance=dir*(entry-snap.logicalSL);
   if(distance<=0) { g_hnStatusText="INVALID SWING STOP"; return; }
   double hardSL=(InpSLMode==CLOSE_BAR_STOP ? NormalizePrice(entry-dir*distance*InpEmergencySLMultiplier,-dir) : snap.logicalSL);
   snap.tp=NormalizePrice(entry+dir*distance*InpRiskReward,dir);
   if(!StopsValid(dir,tick,hardSL,snap.tp)) { g_hnStatusText="BROKER STOP DISTANCE"; return; }
   double lot=CalculateLot(dir,entry,hardSL); lastLot=lot; if(lot<=0) return;
   double margin=0; ENUM_ORDER_TYPE type=(dir==1 ? ORDER_TYPE_BUY : ORDER_TYPE_SELL);
   if(!OrderCalcMargin(type,_Symbol,lot,entry,margin) || margin>AccountInfoDouble(ACCOUNT_MARGIN_FREE)*InpMarginUsePercent/100.0)
     { g_hnStatusText="INSUFFICIENT MARGIN"; return; } // video lot is NOT reduced silently
   MqlTradeRequest request={}; MqlTradeCheckResult checked={};
   request.action=TRADE_ACTION_DEAL; request.symbol=_Symbol; request.magic=InpMagic;
   request.volume=lot; request.type=type; request.price=entry; request.sl=hardSL; request.tp=snap.tp;
   request.deviation=(ulong)InpMaxSlippagePoints;
   long fill=SymbolInfoInteger(_Symbol,SYMBOL_FILLING_MODE);
   if((fill & SYMBOL_FILLING_FOK)!=0) request.type_filling=ORDER_FILLING_FOK;
   else if((fill & SYMBOL_FILLING_IOC)!=0) request.type_filling=ORDER_FILLING_IOC;
   else request.type_filling=ORDER_FILLING_RETURN;
   if(!OrderCheck(request,checked)) { g_hnStatusText="ORDER CHECK FAILED"; PrintFormat("CHECK: %u %s",checked.retcode,checked.comment); return; }
   pendingCloseReason="";
   bool sent=(dir==1 ? trade.Buy(lot,_Symbol,entry,hardSL,snap.tp,"HN_V1") : trade.Sell(lot,_Symbol,entry,hardSL,snap.tp,"HN_V1"));
   if(!TradeDone(sent))
     { g_hnStatusText="ORDER REJECTED"; PrintFormat("ENTRY: %u %s",trade.ResultRetcode(),trade.ResultRetcodeDescription()); historyDirty=true; return; }
   historyDirty=true; g_hnStatusText=(dir==1 ? "BUY OPEN" : "SELL OPEN");
   for(int i=0;i<PositionsTotal();i++)
      if(PositionGetTicket(i)!=0 && OwnSelectedPosition())
        { SavePositionState((ulong)PositionGetInteger(POSITION_IDENTIFIER)); break; }
  }
string DealReasonText(const ENUM_DEAL_REASON reason,const ENUM_DEAL_ENTRY entry)
  {
   if(entry==DEAL_ENTRY_IN) return "ENTRY";
   if(reason==DEAL_REASON_SL) return (InpSLMode==CLOSE_BAR_STOP ? "EMERGENCY_SL" : "FIXED_SL");
   if(reason==DEAL_REASON_TP) return "RR_TP";
   if(reason==DEAL_REASON_SO) return "STOP_OUT";
   if(reason==DEAL_REASON_EXPERT && pendingCloseReason!="") return pendingCloseReason;
   return EnumToString(reason);
  }
void OnTradeTransaction(const MqlTradeTransaction &trans,const MqlTradeRequest &request,const MqlTradeResult &result)
  {
   if(trans.type!=TRADE_TRANSACTION_DEAL_ADD || trans.deal==0 || !HistoryDealSelect(trans.deal)) return;
   historyDirty=true; // includes other-symbol P/L and cash flows in the day-start denominator
   ulong id=trans.deal,pid=(ulong)HistoryDealGetInteger(id,DEAL_POSITION_ID);
   if(HistoryDealGetString(id,DEAL_SYMBOL)!=_Symbol) return;
   bool own=((ulong)HistoryDealGetInteger(id,DEAL_MAGIC)==InpMagic || pid==statePositionId ||
             (!tester && GlobalVariableCheck(StateKey(pid,"SL"))));
   if(!own) return;
   historyDirty=true;
   ENUM_DEAL_ENTRY entry=(ENUM_DEAL_ENTRY)HistoryDealGetInteger(id,DEAL_ENTRY);
   bool snapshotKnown=LoadPositionState(pid);
   if(logHandle==INVALID_HANDLE) return;
   ENUM_DEAL_TYPE type=(ENUM_DEAL_TYPE)HistoryDealGetInteger(id,DEAL_TYPE);
   ENUM_DEAL_REASON reason=(ENUM_DEAL_REASON)HistoryDealGetInteger(id,DEAL_REASON);
   // DEAL_* side is actual deal direction: a SELL exit closes a BUY position.
   FileWrite(logHandle,TimeToString((datetime)HistoryDealGetInteger(id,DEAL_TIME),TIME_DATE|TIME_SECONDS),
             EnumToString(entry),IdText(pid),IdText(id),EnumToString(type),HistoryDealGetDouble(id,DEAL_VOLUME),
             HistoryDealGetDouble(id,DEAL_PRICE),snapshotKnown ? snap.logicalSL : 0.0,
             snapshotKnown ? snap.tp : 0.0,snapshotKnown ? snap.d1 : 0,snapshotKnown ? snap.h4 : 0,
             snapshotKnown ? snap.h1 : 0,snapshotKnown ? snap.m15 : 0,snapshotKnown ? snap.slope : 0.0,
             snapshotKnown ? snap.adx : 0.0,snapshotKnown ? snap.atr : 0.0,snapshotKnown ? snap.spread : 0.0,
             HistoryDealGetDouble(id,DEAL_PROFIT),HistoryDealGetDouble(id,DEAL_COMMISSION),
             HistoryDealGetDouble(id,DEAL_SWAP),HistoryDealGetDouble(id,DEAL_FEE),
             snapshotKnown ? snap.riskMoney : 0.0,DealReasonText(reason,entry),snapshotKnown);
   FileFlush(logHandle);
  }
void Display()
  {
   if(MQLInfoInteger(MQL_OPTIMIZATION)) return;
   datetime current=iTime(_Symbol,PERIOD_M3,0);
   if(current!=panelBar)
     {
      panelBar=current;
      panel.d1=TrendDirection(trendMA[0],atrHandle[0],PERIOD_D1,false,INVALID_HANDLE);
      panel.h4=TrendDirection(trendMA[1],atrHandle[1],PERIOD_H4,false,INVALID_HANDLE);
      panel.h1=TrendDirection(trendMA[2],atrHandle[2],PERIOD_H1,false,INVALID_HANDLE);
      panel.m15=TrendDirection(fastMA[0],atrHandle[3],PERIOD_M15,InpUseSlowMAFilter,slowMA[0]);
      double recent=0,older=0;
      if(!BufferValue(adxHandle,0,1,panel.adx)) panel.adx=0;
      if(!BufferValue(atrHandle[4],0,1,panel.atr)) panel.atr=0;
      panel.slope=0;
      if(panel.atr>0 && BufferValue(fastMA[1],0,1,recent) && BufferValue(fastMA[1],0,1+InpSlopeBars,older))
         panel.slope=(recent-older)/panel.atr;
     }
   Comment("Himeneko Gold Research V1\n",_Symbol," / ",AccountInfoString(ACCOUNT_CURRENCY),
           "\nD1: ",panel.d1,"  H4: ",panel.h4,"  H1: ",panel.h1,"  M15: ",panel.m15,
           "\nM3 slope/ATR: ",DoubleToString(panel.slope,4),"  ADX: ",DoubleToString(panel.adx,2),
           "\nATR: ",DoubleToString(panel.atr,_Digits),"  Spread(points): ",DoubleToString(currentSpread,1),
           "\nLast calculated lot: ",DoubleToString(lastLot,4),"  Daily P/L incl. floating: ",DoubleToString(realizedToday+FloatingPL(),2),
           "\nTrades today: ",tradesToday,"  Consecutive losses(today): ",lossStreak,
           "\nNew entries: ",dayHalted ? "HALTED" : g_hnStatusText);
  }
bool InputsValid()
  {
   return (int)InpRiskMode>=0 && (int)InpRiskMode<=2 && (int)InpSLMode>=0 && (int)InpSLMode<=1 &&
          (int)InpEntryTrigger>=0 && (int)InpEntryTrigger<=3 && (int)InpTouchMode>=0 && (int)InpTouchMode<=1 &&
          (int)InpMAMethod>=0 && (int)InpMAMethod<=3 && (int)InpMAPrice>=1 && (int)InpMAPrice<=7 &&
          InpMagic>0 && InpMaxPositions==1 && InpFastMA>=2 && InpSlowMA>=2 && InpTrendMA>=2 &&
          InpSlopeBars>=1 && InpSlopeBars<=50 && InpPullbackLookback>=2 && InpPullbackLookback<=200 &&
          InpSwingLookback>=2 && InpSwingLookback<=200 && InpATRPeriod>=2 && InpADXPeriod>=2 &&
          InpFastMA<=2000 && InpSlowMA<=2000 && InpTrendMA<=2000 && InpATRPeriod<=2000 && InpADXPeriod<=2000 &&
          InpMinTrendSlopeATR>=0 && InpFlatSlopeATR>=0 && InpTouchATR>=0 && InpSLBufferATR>=0 &&
          InpRiskReward>0 && InpEmergencySLMultiplier>=1 && InpRiskPercent>0 && InpRiskPercent<=100 &&
          InpFixedLot>0 && InpMaxLot>0 && InpRoundTripCostPerLot>=0 && InpMarginUsePercent>0 && InpMarginUsePercent<=100 &&
          InpMaxDailyLossPercent>=0 && InpMaxDailyLossPercent<=100 && InpMaxDailyTrades>=0 &&
          InpMaxConsecutiveLosses>=0 && InpMaxSpreadPoints>=0 && InpMaxSlippagePoints>=0 &&
          InpMinADX>=0 && InpMinADX<=100 && InpMinATR>=0 && InpMaxATR>=0 &&
          (InpMaxATR==0 || InpMaxATR>=InpMinATR) && ValidTag();
  }
int OnInit()
  {
   tester=(bool)MQLInfoInteger(MQL_TESTER);
   for(int i=0;i<3;i++) trendMA[i]=INVALID_HANDLE;
   for(int i=0;i<2;i++) { fastMA[i]=INVALID_HANDLE; slowMA[i]=INVALID_HANDLE; }
   for(int i=0;i<5;i++) atrHandle[i]=INVALID_HANDLE;
   if(!InputsValid() || !ParseSteps()) { Print("INVALID INPUT: check ranges, tag and balance:lot steps."); return INIT_PARAMETERS_INCORRECT; }
   if(InpRiskMode==VIDEO_BALANCE_STEP && AccountInfoString(ACCOUNT_CURRENCY)!=InpStepCurrency)
     { Print("STEP CURRENCY MISMATCH: use JPY or explicitly replace the step table/currency."); return INIT_PARAMETERS_INCORRECT; }
   if(SymbolInfoDouble(_Symbol,SYMBOL_TRADE_TICK_SIZE)<=0 || SymbolInfoDouble(_Symbol,SYMBOL_VOLUME_STEP)<=0) return INIT_FAILED;
   // Tick event is tied to the attached/tested symbol; always use _Symbol.
   for(int i=0;i<5;i++) atrHandle[i]=iATR(_Symbol,frames[i],InpATRPeriod);
   for(int i=0;i<3;i++) trendMA[i]=iMA(_Symbol,frames[i],InpTrendMA,0,InpMAMethod,InpMAPrice);
   for(int i=0;i<2;i++)
     {
      fastMA[i]=iMA(_Symbol,frames[i+3],InpFastMA,0,InpMAMethod,InpMAPrice);
      slowMA[i]=iMA(_Symbol,frames[i+3],InpSlowMA,0,InpMAMethod,InpMAPrice);
     }
   adxHandle=iADX(_Symbol,PERIOD_H1,InpADXPeriod);
   for(int i=0;i<5;i++) if(atrHandle[i]==INVALID_HANDLE) return INIT_FAILED;
   for(int i=0;i<3;i++) if(trendMA[i]==INVALID_HANDLE) return INIT_FAILED;
   for(int i=0;i<2;i++) if(fastMA[i]==INVALID_HANDLE || slowMA[i]==INVALID_HANDLE) return INIT_FAILED;
   if(adxHandle==INVALID_HANDLE) return INIT_FAILED;
   statePrefix="HN1."+StringFormat("%I64d",AccountInfoInteger(ACCOUNT_LOGIN))+"."+IdText(InpMagic)+".";
   if(StringLen(statePrefix)>35) { Print("Magic/login too long for persistent keys"); return INIT_PARAMETERS_INCORRECT; }
   trade.SetExpertMagicNumber(InpMagic); trade.SetDeviationInPoints((ulong)InpMaxSlippagePoints);
   trade.SetAsyncMode(false); trade.SetTypeFillingBySymbol(_Symbol);
   RefreshHistory();
   // Skip the pre-attachment signal; first entry check is next M3 bar.
   lastBar=iTime(_Symbol,PERIOD_M3,0);
   if(InpWriteCSV && !MQLInfoInteger(MQL_OPTIMIZATION))
     {
      string name="HN_V1_"+InpRunTag+"_"+_Symbol+"_"+IdText(InpMagic)+"_deals.csv";
      int flags=FILE_READ|FILE_WRITE|FILE_CSV|FILE_ANSI;
      if(tester) flags=FILE_WRITE|FILE_CSV|FILE_ANSI; // overwrite single test, no FILE_COMMON races
      logHandle=FileOpen(name,flags,',',CP_UTF8);
      if(logHandle==INVALID_HANDLE) { Print("CSV open failed: ",GetLastError()); return INIT_FAILED; }
      if(FileSize(logHandle)==0)
         FileWrite(logHandle,"time","entry","position_id","deal_id","deal_side","volume","price","logical_sl","tp",
                   "d1","h4","h1","m15","m3_slope_atr","adx","atr","entry_spread_points","profit","commission","swap","fee","initial_hard_risk_money","exit_reason","snapshot_known");
      FileSeek(logHandle,0,SEEK_END);
     }
   g_hnStatusText="WAIT NEXT M3 BAR"; return INIT_SUCCEEDED;
  }
void OnTick()
  {
   MqlTick tick; if(!SymbolInfoTick(_Symbol,tick) || tick.bid<=0 || tick.ask<tick.bid) return;
   currentSpread=(tick.ask-tick.bid)/_Point;
   if(historyDirty || !historyOK || ServerDay(TimeCurrent())!=dayStart) RefreshHistory();
   ManageStops(); // exit management never depends on entry spread/ADX/data filters
   if(historyOK && InpMaxDailyLossPercent>0 && realizedToday+FloatingPL()<=-dayStartBalance*InpMaxDailyLossPercent/100.0)
     { LatchDailyStop(); g_hnStatusText="DAILY LOSS LIMIT"; }
   if(dayHalted && InpCloseOnDailyLoss) CloseOwned("DAILY_LOSS_LIMIT");
   datetime current=iTime(_Symbol,PERIOD_M3,0);
   if(current<=0 || current==lastBar) { Display(); return; }
   lastBar=current; // at most one attempt per new bar, including rejected orders
   if(!historyOK) { g_hnStatusText="HISTORY NOT READY"; Display(); return; }
   if(dayHalted) { g_hnStatusText="DAILY HALT"; Display(); return; }
   if(!tester && !InpAllowLiveTrading) { g_hnStatusText="LIVE/DEMO ENTRY DISABLED"; Display(); return; }
   if(!tester && (!MQLInfoInteger(MQL_TRADE_ALLOWED) || !TerminalInfoInteger(TERMINAL_TRADE_ALLOWED) ||
      !AccountInfoInteger(ACCOUNT_TRADE_ALLOWED) || !AccountInfoInteger(ACCOUNT_TRADE_EXPERT)))
     { g_hnStatusText="TRADING PERMISSION DISABLED"; Display(); return; }
   if(OwnPositions()>=InpMaxPositions || AnySymbolExposure()) { g_hnStatusText="SYMBOL EXPOSURE EXISTS"; Display(); return; }
   if(InpMaxDailyTrades>0 && tradesToday>=InpMaxDailyTrades) { g_hnStatusText="DAILY TRADE COUNT LIMIT"; Display(); return; }
   if(InpMaxConsecutiveLosses>0 && lossStreak>=InpMaxConsecutiveLosses) { LatchDailyStop(); g_hnStatusText="LOSS STREAK LIMIT"; Display(); return; }
   if(InpMaxSpreadPoints>0 && currentSpread>InpMaxSpreadPoints) { g_hnStatusText="SPREAD FILTER"; Display(); return; }
   if(!ReadSignalData()) { g_hnStatusText="INDICATORS WARMING UP"; Display(); return; }
   snap.spread=currentSpread;
   if(InpUseADX && snap.adx<InpMinADX) { g_hnStatusText="ADX RANGE FILTER"; Display(); return; }
   if((InpMinATR>0 && snap.atr<InpMinATR)||(InpMaxATR>0 && snap.atr>InpMaxATR)) { g_hnStatusText="ATR FILTER"; Display(); return; }
   int dir=snap.d1;
   if(dir==0 || snap.h4!=dir || snap.h1!=dir || snap.m15!=dir) { g_hnStatusText="TREND MISMATCH"; Display(); return; }
   double swing=0; if(EntrySignal(dir,swing)) TryEntry(dir,swing,tick);
   Display();
  }
double OnTester()
  {
   if(InpWriteCSV && !MQLInfoInteger(MQL_OPTIMIZATION))
     {
      int f=FileOpen("HN_V1_"+InpRunTag+"_summary.csv",FILE_WRITE|FILE_CSV|FILE_ANSI,',',CP_UTF8);
      if(f!=INVALID_HANDLE)
        {
         FileWrite(f,"run_tag","risk_mode","risk_percent","initial_deposit","net_profit","balance_dd_pct","equity_dd_pct","profit_factor","win_rate_pct","average_win","average_loss","max_consecutive_losses","recovery_factor","trades","currency");
         double total=TesterStatistics(STAT_TRADES),wins=TesterStatistics(STAT_PROFIT_TRADES),losses=TesterStatistics(STAT_LOSS_TRADES);
         FileWrite(f,InpRunTag,(int)InpRiskMode,InpRiskPercent,TesterStatistics(STAT_INITIAL_DEPOSIT),TesterStatistics(STAT_PROFIT),
                   TesterStatistics(STAT_BALANCE_DDREL_PERCENT),TesterStatistics(STAT_EQUITY_DDREL_PERCENT),TesterStatistics(STAT_PROFIT_FACTOR),
                   total>0 ? wins/total*100.0 : 0.0,wins>0 ? TesterStatistics(STAT_GROSS_PROFIT)/wins : 0.0,
                   losses>0 ? TesterStatistics(STAT_GROSS_LOSS)/losses : 0.0,TesterStatistics(STAT_MAX_CONLOSS_TRADES),
                   TesterStatistics(STAT_RECOVERY_FACTOR),total,AccountInfoString(ACCOUNT_CURRENCY));
         FileClose(f);
        }
     }
   return TesterStatistics(STAT_RECOVERY_FACTOR);
  }
void OnDeinit(const int reason)
  {
   for(int i=0;i<5;i++) if(atrHandle[i]!=INVALID_HANDLE) IndicatorRelease(atrHandle[i]);
   for(int i=0;i<3;i++) if(trendMA[i]!=INVALID_HANDLE) IndicatorRelease(trendMA[i]);
   for(int i=0;i<2;i++) { if(fastMA[i]!=INVALID_HANDLE) IndicatorRelease(fastMA[i]); if(slowMA[i]!=INVALID_HANDLE) IndicatorRelease(slowMA[i]); }
   if(adxHandle!=INVALID_HANDLE) IndicatorRelease(adxHandle);
   if(logHandle!=INVALID_HANDLE) FileClose(logHandle);
   Comment("");
  }
