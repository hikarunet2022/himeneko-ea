# V1.10 パラメータ一覧

未確定値はバックテスト用の仮設定です。今回の全設定ファイルは全inputを含みます。

| パラメータ | 初期値 | 説明 |
|---|---|---|
| `InpMagic` | `26100510` | このEAの注文を識別する番号。旧版から変更。 |
| `InpAllowLiveTrading` | `false` | falseならテスターのみ新規注文。通常チャートではデモ口座も発注しない。 |
| `InpMaxPositions` | `1` | 同時保有数。今回のV1は1のみ。 |
| `InpMaxSpreadPoints` | `500` | 許容スプレッド。ブローカーのPoint単位。0なら制限なし。 |
| `InpMaxSlippagePoints` | `20` | 許容約定ずれ（Point）。必ずこの幅に収まる保証ではない。 |
| `InpMarginUsePercent` | `80.0` | 余剰証拠金の何％まで必要証拠金に使うか。 |
| `InpRunTag` | `video_ema` | 結果ファイルの識別名。英数字・_・-のみ、1～32文字。 |
| `InpWriteCSV` | `true` | 約定CSV、結果CSV、理由集計CSVの出力。 |
| `InpWriteDecisionCSV` | `true` | M3判定ごとの詳細CSV出力。理由の操作ログ集計はこの設定に関係なく出す。 |
| `InpRiskMode` | `VIDEO_BALANCE_STEP` | RISK_PERCENT=0 / VIDEO_BALANCE_STEP=1 / FIXED_LOT=2。 |
| `InpRiskPercent` | `1.0` | 1取引のSL損失予算％。RiskPercentモードのみ。 |
| `InpFixedLot` | `0.1` | 固定ロットモードの数量。 |
| `InpMaxLot` | `10.0` | 全モードのロット上限。 |
| `InpRoundTripCostPerLot` | `0.0` | 1lotの往復費用の追加見積り。口座通貨。実際のブローカー手数料を設定する欄ではない。 |
| `InpStepCurrency` | `JPY` | 残高ロット表の金額の通貨。初期JPY。 |
| `InpBalanceLotSteps` | `0:0.1;10000:0.1;30000:0.2;50000:0.3;100000:0.5;150000:0.5;300000:0.7;500000:1.0;1000000:1.6` | 残高:lotを;で区切る表。0開始可、残高は昇順。全部仮定、編集可。 |
| `InpProportionalAboveLastStep` | `true` | 表の最後を超えた残高に比例してlotを増やす。MaxLotまで。 |
| `InpUseManualStepConversion` | `true` | 口座と表の通貨が異なる場合、明示した固定換算を使う。 |
| `InpConversionAccountCurrency` | `USD` | 換算値の適用を許す口座通貨。誤換算防止。 |
| `InpStepUnitsPerAccountUnit` | `150.0` | 口座通貨1単位あたり表の通貨の単位数。JPY表・USD口座ならJPY/USD。150は現在相場ではなく仮定。 |
| `InpStopBelowFirstStep` | `false` | trueなら表の先頭残高未満で停止。falseなら先頭のlotを使う。 |
| `InpEnableLong` | `true` | 買い注文を許可。 |
| `InpEnableShort` | `true` | 売り注文を許可。左右対称の補完ロジックなので買いのみと比較可能。 |
| `InpTrendMode` | `AUTO_DIRECTION` | AUTO_DIRECTION=0 / LONG_ONLY=1 / SHORT_ONLY=2。方向固定でもMAの確認は必要。 |
| `InpTrendAlignment` | `STRICT_ALIGNMENT` | STRICT_ALIGNMENT=0（全て同方向）/ NO_OPPOSING_TREND=1（M15必須、上位横ばい可）。 |
| `InpUseD1Trend` | `false` | 日足一致の追加条件。新版の初期OFF。 |
| `InpUseH1Trend` | `true` | H1の傾き方向チェックを使う。 |
| `InpUseH4Trend` | `true` | H4の傾き方向チェックを使う。 |
| `InpFastMA` | `20` | M3のMA期間。20。 |
| `InpM15MA` | `20` | M15のMA期間。20は仮定。 |
| `InpHigherMA` | `20` | H1/H4のMA期間。20は仮定。 |
| `InpTrendMA` | `200` | 任意のD1用MA期間。D1がOFFなら影響なし。 |
| `InpMAMethod` | `MODE_EMA` | MODE_SMA=0、MODE_EMA=1、MODE_SMMA=2、MODE_LWMA=3。 |
| `InpMAPrice` | `PRICE_CLOSE` | MAに使う価格。PRICE_CLOSE=1（終値）。 |
| `InpSlopeBars` | `3` | MA[1]とMA[1+N]を比べるN。 |
| `InpMinTrendSlopeATR` | `0.02` | (確定MA－N本前MA)/ATRの方向判定しきい値。1本あたりの傾きではない。 |
| `InpTrendRequirePriceSide` | `false` | trueなら方向に加え終値がMAの上／下にあることも必須。 |
| `InpUseADX` | `true` | 補完のレンジ除外を使う。 |
| `InpADXPeriod` | `14` | H1のADX期間。 |
| `InpMinADX` | `20.0` | ADX最低値。20以上を許可。 |
| `InpATRPeriod` | `14` | 各時間足のATR期間。 |
| `InpMinATR` | `0.0` | M3 ATRの下限。価格単位、0なら無効。 |
| `InpMaxATR` | `0.0` | M3 ATRの上限。価格単位、0なら無効。 |
| `InpTouchMode` | `MA_REBOUND` | MA_REBOUND=0（Low/Highタッチ＋終値反発）、BODY_NEAR_MA=1（実体距離）、CLOSE_NEAR_MA=2（終値距離）。 |
| `InpTouchATR` | `0.2` | 距離型タッチの許容幅＝M3 ATR×値。MA_REBOUNDでは使わない。 |
| `InpUseRSI` | `true` | RSIの条件を使う。OFFは補完比較用で本人発言寄り設定と区別。 |
| `InpRSIPeriod` | `14` | M3 RSI期間。14は仮定。適用価格は終値。 |
| `InpRSIBuyLevel` | `20.0` | 買いRSIがこの値以下。 |
| `InpRSISellLevel` | `80.0` | 売りRSIがこの値以上。 |
| `InpRSILookback` | `1` | 1はシグナル足の終値RSI。Nは直近N確定足で到達していれば許可。N>1は別仮説。 |
| `InpUseWickFilter` | `true` | 長いヒゲ条件を使う。 |
| `InpWickBodyRatio` | `1.5` | 方向に対応するヒゲ／実体の最低比率。 |
| `InpLowerWickPercent` | `40.0` | 買いの下ヒゲ／足全体の最低％。 |
| `InpUpperWickPercent` | `40.0` | 売りの上ヒゲ／足全体の最低％。 |
| `InpBodyFloorPoints` | `1.0` | 実体がゼロに近い足の比率計算に使う最小実体幅（Point）。 |
| `InpRequireSignalColor` | `false` | 買いなら陽線、売りなら陰線も必須にする。初期false。 |
| `InpCooldownBars` | `1` | 決済足以降の待機M3本数。0でも同じ／古いシグナルで再エントリーしない。 |
| `InpSLBasis` | `SWING_STOP` | SWING_STOP=0 / SIGNAL_CANDLE_STOP=1 / ATR_STOP=2 / FIXED_DISTANCE_STOP=3。 |
| `InpSwingLookback` | `10` | シグナル足を含む確定M3の最低／最高を探す本数。 |
| `InpSLBufferATR` | `0.1` | Swing/シグナル足SLに加えるATR幅。 |
| `InpSLATRMultiplier` | `1.0` | ATR_STOPのSL距離倍率。 |
| `InpSLDistancePrice` | `2.0` | 固定距離SLの価格幅。ゴールドの曖昧なpips表記は使わない。 |
| `InpSLMode` | `FIXED_STOP` | FIXED_STOP=0（根拠位置に固定SL）/ CLOSE_BAR_STOP=1（終値SL＋緊急SL）。 |
| `InpEmergencySLMultiplier` | `3.0` | 終値型SLの緊急固定SL距離倍率。固定型では不使用。 |
| `InpTPMode` | `BB_TARGET` | RR_TARGET=0 / BB_TARGET=1。 |
| `InpBBPeriod` | `20` | BB期間。20は仮定。 |
| `InpBBDeviation` | `2.0` | BB偏差。2.0は仮定。 |
| `InpBBTimeframe` | `PERIOD_M3` | 利確BBの時間足。M3が仮の初期値。 |
| `InpRiskReward` | `1.5` | RR利確の倍率。BB利確では不使用。 |
| `InpUseSupportResistance` | `false` | 任意の簡易H1/H4確定Swing障害フィルター。初期OFF。 |
| `InpSRLookback` | `50` | SRに使う確定H1/H4本数。 |
| `InpSRDistanceATR` | `0.5` | 進行方向の抵抗帯までの最低距離＝M3 ATR×値。近すぎると禁止。 |
| `InpMaxDailyLossPercent` | `0.0` | 日開始残高に対する当日確定＋含み損益の最大損失％。0でOFF。 |
| `InpCloseOnDailyLoss` | `true` | 日次損失停止時に自分のポジションを閉じる。 |
| `InpMaxDailyTrades` | `0` | 1日最大エントリー注文数。0で制限なし。 |
| `InpMaxConsecutiveLosses` | `0` | 当日完了したポジションの連敗停止。0でOFF。 |
